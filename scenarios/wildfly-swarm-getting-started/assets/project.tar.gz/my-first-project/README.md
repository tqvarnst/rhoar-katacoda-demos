http://appdev.prod-preview.openshift.io/docs/wf-swarm-runtime.html#mission-health-check-wf-swarm
